//
//  main.m
//  Mar28
//
//  Created by Joe Gabela on 4/1/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Mar28AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Mar28AppDelegate class]));
    }
}
