//
//  View.h
//  Mar28
//
//  Created by Joe Gabela on 4/1/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View: UIView {
	UISlider *slider;
	UILabel *label;
}

@end